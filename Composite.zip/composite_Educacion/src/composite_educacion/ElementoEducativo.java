/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package composite_educacion;

/**
 *
 * @author Adrian
 */
public abstract class ElementoEducativo {

    protected String nombre;

    public abstract String getNombreElemento();

    public abstract boolean agregaHoja(ElementoEducativo elemento);

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}
