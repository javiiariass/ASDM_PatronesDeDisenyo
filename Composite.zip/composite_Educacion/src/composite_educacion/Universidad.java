/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package composite_educacion;

import java.util.ArrayList;

/**
 *
 * @author Adrian
 */
public class Universidad extends ElementoEducativo{
    ArrayList<ElementoEducativo> elementos=new ArrayList<ElementoEducativo>();
    @Override
    public boolean agregaHoja(ElementoEducativo elemento) {
            return elementos.add(elemento);
    }
     @Override
    public String getNombreElemento() {
        String s=""+getNombreElemento();
        for(ElementoEducativo elemento:elementos){
            s+=elemento.getNombreElemento();
        }
        return s;
    }

   
    
}
