/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package composite_educacion;

/**
 *
 * @author Adrian
 */
public class DepartamentoInvestigacion extends ElementoEducativo {

    @Override
    public boolean agregaHoja(ElementoEducativo elemento) {
        return false;
    }
     @Override
    public String getNombreElemento() {
        return nombre;
    }

}
