/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package composite_vehiculos;

/**
 *
 * @author Adrian
 */
public class Composite_Vehiculos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Empresa em1=new EmpresaSinFilial();
        em1.agregaVehiculo();
        Empresa em2=new EmpresaSinFilial();
        em2.agregaVehiculo();
        em2.agregaVehiculo();
        
        Empresa mama1=new EmpresaMadre();
        mama1.agregaVehiculo();
                
                mama1.agregaFilial(em1);
        mama1.agregaFilial(em2);
        System.out.println(mama1.calculaCosteMantenimientos());
        
            
    }
    
}
