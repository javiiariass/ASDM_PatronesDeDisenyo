/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package composite_vehiculos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Adrian
 */
public class EmpresaMadre extends Empresa{
    protected ArrayList<Empresa> filiales=new ArrayList<Empresa>();
        
    @Override
    public double calculaCosteMantenimientos() {
        double coste=0.0;
        for(Empresa filial:filiales){
        coste+=filial.calculaCosteMantenimientos();//sumamos los coste de los filiales y de la madre
        }
        
        
        return coste+n_vehiculos*costeUnitrarioVehiculor;
    }

    @Override
    public boolean agregaFilial(Empresa filial) {
        return filiales.add(filial);
    }
    
}
