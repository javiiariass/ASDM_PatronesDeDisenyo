/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package composite_vehiculos;

/**
 *
 * @author Adrian
 */
public abstract class Empresa {

    protected static double costeUnitrarioVehiculor = 50.0;
    protected int n_vehiculos;

    public void agregaVehiculo() {
        n_vehiculos++;
    }
    public abstract double calculaCosteMantenimientos();
    public abstract boolean agregaFilial(Empresa filial);
    
}
